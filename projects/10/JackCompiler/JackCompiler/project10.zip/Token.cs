﻿namespace JackCompiler
{
    public record Token(string Value, TokenType Type, Marker Marker);
}